To run the software see paper:
https://doi.org/10.1016/j.envsoft.2018.03.024